const express = require("express");
const multer = require("multer");
const { google } = require("googleapis");
const fs = require("fs");
const path = require("path");
const pool = require("./db"); // your PostgreSQL pool config

const router = express.Router();
const upload = multer({ dest: "uploads/" });

// Google Auth setup
const auth = new google.auth.GoogleAuth({
  keyFile: path.join(__dirname, "service-account.json"),
  scopes: ["https://www.googleapis.com/auth/drive.file"],
});

router.post("/upload", upload.single("pdfFile"), async (req, res) => {
  try {
    const authClient = await auth.getClient();
    const drive = google.drive({ version: "v3", auth: authClient });

    const fileMetadata = {
      name: req.file.originalname,
      parents: ["1gfcdDNiV55S1hUqXurp1Yef9WkQXnHQT"], 
    };

    const media = {
      mimeType: "application/pdf",
      body: fs.createReadStream(req.file.path),
    };

    const response = await drive.files.create({
      resource: fileMetadata,
      media,
      fields: "id, webViewLink",
    });

    const webViewLink = response.data.webViewLink;
    const numcart = req.body.numcart;

    // Insert into database
    await pool.query(
  `UPDATE rapport_links 
   SET link = $1, status = $2 
   WHERE numcart = $3`,
  [webViewLink, "validé", numcart]
);


    // Clean up local file
    fs.unlinkSync(req.file.path);

    console.log("File uploaded:", response.data);

    res.status(200).json({
      message: "✅ Fichier envoyé avec succès",
      fileId: response.data.id,
      link: webViewLink,
    });
  } catch (err) {
    console.error("Upload error:", err);
    res.status(500).json({ message: "Erreur lors de l'envoi du fichier", error: err.message });
  } finally {
    
    if (filePath && fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  }
});

module.exports = router;
