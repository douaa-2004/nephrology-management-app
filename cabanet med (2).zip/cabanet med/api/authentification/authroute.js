const express = require("express");
const router = express.Router()

const login = require("./authcontroller")

router.post("/login", login)
module.exports = router