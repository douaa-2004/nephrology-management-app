const pool = require('../db');
const login = async (req, res) => {
    const { email, password } = req.body;
  
    try {
      const result = await pool.query(
        "SELECT * FROM public.connexion WHERE email = $1 AND password = $2",
        [email, password]
      );
  
      if (result.rows.length === 0) {
        return res.status(401).json({ message: "Email ou mot de passe invalide" });
      }
  
      const user = result.rows[0];
  
      // Si le rôle est "patient", retourner aussi ses données personnelles
   
        const userinfo = await pool.query(
          "SELECT * FROM dossier_patient WHERE email = $1",
          [email]
        );
  
        return res.status(200).json({
          role: user.role,
          email: user.email,
          patient: userinfo.rows[0],
        });
      
  
      // Si c’est un médecin ou assistant
      return res.status(200).json({
        role: user.role,
        email: user.email,
      });
  
    } catch (err) {
      console.error("Erreur login:", err);
      res.status(500).json({ message: "Erreur serveur" });
    }
  };

  module.exports = login