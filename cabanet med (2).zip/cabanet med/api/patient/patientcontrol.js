const pool = require("../db");

// Patient requests a report
const demanderRapport = async (req, res, next) => {
    try {
      const { numcart } = req.params;
  
      // Check if already requested and still pending
      const existing = await pool.query(
        "SELECT * FROM rapport_links WHERE numcart = $1 AND status = 'en_attente'",
        [numcart]
      );
      if (existing.rows.length > 0) {
        return res.status(200).json({ message: "Demande déjà en attente", success: true });
      }
  
      // Get patient info from dossier_patient
      const patient = await pool.query(
        "SELECT firstname, lastname, phone, email FROM dossier_patient WHERE numcart = $1",
        [numcart]
      );
  
      if (patient.rows.length === 0) {
        return res.status(404).json({ message: "Patient non trouvé", success: false });
      }
  
      const { firstname, lastname, phone, email } = patient.rows[0];
  
      await pool.query(
        `INSERT INTO rapport_links (numcart, firstname, lastname, phone, email, status)
         VALUES ($1, $2, $3, $4, $5, 'en_attente')`,
        [numcart, firstname, lastname, phone, email]
      );
  
      res.status(201).json({ message: "Demande enregistrée avec succès", success: true });
    } catch (error) {
      next(error);
    }
  };
  

// Polling from patient
const checkRapportStatus = async (req, res, next) => {
  try {
    const { numcart } = req.params;
    const result = await pool.query(
      "SELECT status, link FROM rapport_links WHERE numcart = $1 ORDER BY created_at DESC LIMIT 1",
      [numcart]
    );

    if (result.rows.length === 0) {
      return res.status(200).json({ success: false, message: "Aucune demande trouvée." });
    }

    const { status, link } = result.rows[0];

    if (status === "validé" && link) {
      return res.status(200).json({ success: true, link});
    } else {
      return res.status(200).json({ success: false , message: "Rapport en attente de validation."});
    }
  } catch (error) {
    next(error);
  }
};

// Doctor sets report link
const setRapportLink = async (req, res, next) => {
  try {
    const { numcart, rapport_link } = req.body;

    const result = await pool.query(
      `UPDATE demanderapport SET rapport_link = $1, status = 'prêt'
       WHERE numcart = $2 AND status = 'en_attente'
       RETURNING *`,
      [rapport_link, numcart]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: "Demande non trouvée ou déjà complétée." });
    }

    res.status(200).json({ success: true, message: "Lien du rapport envoyé avec succès." });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  demanderRapport,
  checkRapportStatus,
  setRapportLink,
};
