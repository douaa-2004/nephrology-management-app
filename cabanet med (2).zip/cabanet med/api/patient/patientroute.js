const express = require("express");
const router = express.Router();
const { demanderRapport, checkRapportStatus, setRapportLink } = require("../patient/patientcontrol.js");

router.post("/demander-rapport/:numcart", demanderRapport);
router.get("/rapport/:numcart", checkRapportStatus);
router.post("/send-rapport-link", setRapportLink); 
module.exports = router;
