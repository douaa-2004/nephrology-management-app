// server.js
const express = require('express');
const app = express();
const assestant  = require("./assestant/assestantroute")
const medcin = require("./medcin/medcinroutes")
const auth = require("./authentification/authroute")
const patient = require("./patient/patientroute")
const cors = require("cors");
app.use(cors()); 
app.use(express.json());
app.use("/api/medcin" , medcin)
app.use("/api/auth" , auth)
app.use("/api/assestant" , assestant)
app.use("/api/patient" , patient)
app.get('/', (req, res) => {
  res.send('Hello, Node.js is running!');
});


const googleDriveRoute = require("./googledrive");
app.use("/api/drive", googleDriveRoute);
const examSaveRoute = require("./examsave");
app.use("/api/exam", examSaveRoute);

app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  const message = err.message || "Internal  Error";
  return res.status(statusCode).json({
    success: false,
    statusCode,
    message,
  });
});
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
