const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");
const pool = require("./db");

const router = express.Router();
const upload = multer({ dest: "uploads/" });

const auth = new google.auth.GoogleAuth({
  keyFile: path.join(__dirname, "service-account.json"),
  scopes: ["https://www.googleapis.com/auth/drive.file"],
});

router.post("/upload", upload.single("pdfFile"), async (req, res) => {
  try {
    const authClient = await auth.getClient();
    const drive = google.drive({ version: "v3", auth: authClient });

    const fileMetadata = {
      name: req.file.originalname,
      parents: ["1gfcdDNiV55S1hUqXurp1Yef9WkQXnHQT"], 
    };

    const media = {
      mimeType: "application/pdf",
      body: fs.createReadStream(req.file.path),
    };

    const response = await drive.files.create({
      resource: fileMetadata,
      media,
      fields: "id, webViewLink",
    });

    const webViewLink = response.data.webViewLink;
    const numcart = req.body.numcart;

    // Optionally store the exam link
  await pool.query(
  `INSERT INTO exam_links (numcart, link, status) 
   VALUES ($1, $2, $3)`,
  [numcart, webViewLink, "validé"]
);

    fs.unlinkSync(req.file.path);

    res.status(200).json({
      success: true,
      link: webViewLink,
    });
  } catch (err) {
    console.error("Erreur lors de l'envoi:", err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
