const pool = require('../db');
const crypto = require('crypto');

const addFicheClinique = async (req, res) => {
    const {
      numcart,
      sexe,
      antMed,
      antChir,
      antGyneco,
      habitudes,
      antFamiliaux,
      examenClinique,
    } = req.body;
  
    try {
      await pool.query(
        `INSERT INTO fiche_clinique (numcart, sexe, ant_med, ant_chir, ant_gyneco, habitudes, ant_familiaux, examen_clinique)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [numcart, sexe, antMed, antChir, antGyneco, habitudes, antFamiliaux, examenClinique]
      );
  
      res.json({ success: true, message: "Fiche clinique enregistrée" });
    } catch (error) {
      console.error("Erreur insertion fiche clinique :", error);
      res.status(500).json({ success: false, message: "Erreur serveur" });
    }
  };



const getFicheCliniqueByNumCart = async (req, res) => {
  const { numcart } = req.params;

  try {
    const result = await pool.query("SELECT * FROM fiche_clinique WHERE numcart = $1", [numcart]);

    if (result.rows.length === 0) {
      return res.json({ success: false, message: "Fiche non trouvée" });
    }

    return res.json({ success: true, fiche: result.rows[0] });
    console.log(result.rows[0])
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Erreur serveur" });
  }
};

// PUT mettre à jour fiche clinique
const updateFicheClinique = async (req, res) => {
    const { numcart } = req.params;
    const {
        sexe,
        ant_med,
        ant_chir,
        ant_gyneco,
        habitudes,
        ant_familiaux,
        examen_clinique,
    } = req.body;
  
    try {
      // Adjusting the column names to match the table definition
      const result = await pool.query(
        `UPDATE fiche_clinique SET
          sexe = $1,
          ant_med = $2,
          ant_chir = $3,
          ant_gyneco = $4,
          habitudes = $5,
          ant_familiaux = $6,
          examen_clinique = $7
        WHERE numcart = $8`,
        [sexe, ant_med, ant_chir, ant_gyneco, habitudes, ant_familiaux, examen_clinique, numcart]
      );
  
      return res.json({ success: true, message: "Fiche mise à jour" });
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, message: "Erreur serveur" });
    }
  };
  

    const checkPatientExist = async (req, res) => {
    const { numcart } = req.params;
  
    try {
      const result = await pool.query(
        "SELECT numcart FROM fiche_clinique WHERE numcart = $1",
        [numcart]
      );
  
      if (result.rows.length > 0) {
        res.json({ exists: true });
      } else {
        res.json({ exists: false });
      }
    } catch (err) {
      console.error("Erreur serveur :", err);
      res.status(500).json({ error: "Erreur serveur" });
    }
  };
  const fichecliniquecon = async (req, res) => {
    
        const { numcart } = req.params;
      
        try {
          const result = await pool.query(
            `SELECT dp.firstname, dp.lastname, dp.birthdate,
                    fc.sexe, fc.ant_med, fc.ant_chir,
                    fc.ant_gyneco, fc.habitudes, fc.ant_familiaux, fc.examen_clinique
             FROM dossier_patient dp
             JOIN fiche_clinique fc ON dp.numcart = fc.numcart
             WHERE dp.numcart = $1`,
            [numcart]
          );
      
          if (result.rows.length > 0) {
            res.json({ success: true, fiche: result.rows[0] });
          } else {
            res.json({ success: false, message: "Fiche non trouvée" });
          }
        } catch (err) {
          console.error("Erreur serveur :", err);
          res.status(500).json({ success: false, error: "Erreur serveur" });
        }};
        const getbillan =  async (req, res) => {
          const { numcart } = req.params;
          try {
            const result = await pool.query(
      `SELECT * FROM bilan_patient WHERE numcart = $1 ORDER BY created_at DESC LIMIT 1`,
      [numcart]
    );
            if (result.rows.length === 0) {
              return res.status(404).json({ message: "Patient non trouvé" });
            }
            res.json(result.rows[0]);
          } catch (error) {
            console.error("Erreur lors du fetch bilan:", error);
            res.status(500).json({ message: "Erreur serveur" });
          }
        };
        const pasteBilan = async (req, res) => {
          const { numcart } = req.params;
         try {
    const result = await pool.query(
      `SELECT * FROM bilan_patient WHERE numcart = $1 ORDER BY created_at DESC`,
      [numcart]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
}; 
        
        
        

        const postconduite = async (req, res) => {
          const { texte } = req.body;
          const { numcart } = req.params;
        
          try {
            const result = await pool.query(
              "INSERT INTO conduite_patient (numcart, texte) VALUES ($1, $2) RETURNING *",
              [numcart, texte]
            );
            res.json(result.rows[0]);
          } catch (err) {
            console.error("Erreur lors de l'insertion:", err);
            res.status(500).send("Erreur serveur");
          }
        };
       const getconduite =  async (req, res) => {
  const { numcart } = req.params;

  try {
    const result = await pool.query(
      "SELECT * FROM conduite_patient WHERE numcart = $1 ORDER BY created_at DESC",
      [numcart]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Erreur lors de la récupération:", err);
    res.status(500).send("Erreur serveur");
  }
};
const consulterrapport = async (req, res) => {

  try {
    const result = await pool.query(
      `SELECT id, numcart, firstname, lastname, phone, email, created_at
       FROM rapport_links
       WHERE status = 'en_attente'
       ORDER BY created_at DESC`
    );
console.log(result.rows)
    res.status(200).json({ success: true, demandes: result.rows });
  } catch (error) {
   next(error);
  }
}
const add_assestant = async(req, res) => {

  const { email, password } = req.body;

  try {
    // Check if email already exists
    const existing = await pool.query("SELECT * FROM connexion WHERE email = $1", [email]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ message: "Email déjà utilisé" });
    }

 

    // Insert into DB
    await pool.query(
      `INSERT INTO connexion (email, password, role) VALUES ($1, $2, 'assestant')`,
      [email, password]
    );

    res.status(200).json({ message: "Assistant ajouté avec succès" });
  } catch (err) {
    next(err);
  }
}


module.exports = {
  getbillan,
    addFicheClinique,
  getFicheCliniqueByNumCart,
  updateFicheClinique,
    checkPatientExist ,
    fichecliniquecon ,
    postconduite,
    getconduite,
    consulterrapport ,
    add_assestant,
    pasteBilan
    
};


  
  
  