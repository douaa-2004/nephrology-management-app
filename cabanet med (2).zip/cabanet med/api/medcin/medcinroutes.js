const express = require("express");
const router = express.Router()
const {addFicheClinique ,
     getFicheCliniqueByNumCart ,
     updateFicheClinique ,
      checkPatientExist,
    fichecliniquecon,
    getbillan,
    postconduite,
    getconduite,
    consulterrapport ,
    add_assestant , 
    pasteBilan
    } = require("./medcincontrol")
router.post("/add-fiche-clinique", addFicheClinique)
router.get("/get-fiche-clinique/:numcart", getFicheCliniqueByNumCart);
router.put("/update-fiche-clinique/:numcart", updateFicheClinique);
router.get("/check-patient/:numcart", checkPatientExist);
router.get("/fiche-clinique/:numcart", fichecliniquecon);
router.get("/bilan/:numcart", getbillan);
router.post("/conduite/:numcart", postconduite);
router.get("/conduite/:numcart", getconduite);
router.get("/consulter-rapport", consulterrapport);
router.post("/add_assestant", add_assestant);
router.get("/presedent-bilan/:numcart", pasteBilan);
module.exports = router
