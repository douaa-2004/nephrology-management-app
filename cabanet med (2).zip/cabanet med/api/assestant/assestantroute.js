const express = require("express");
const router = express.Router()
const {addpatient , addBilan , getLastBilanByNumCart  , getPatientsLast24h , setPrioritaire , removePriority, getinfopatient }= require("./assestantcontrol")
router.post("/ajoutedossier" , addpatient)
router.post("/ajouterbillan", addBilan)
router.get("/get-billan/:numcart", getLastBilanByNumCart);
router.get("/recent-patients", getPatientsLast24h);
router.put("/set-prioritaire/:numcart", setPrioritaire);
router.put("/remove-prioritaire/:numcart", removePriority);
router.get("/getinfopatient/:numcart", getinfopatient);
module.exports = router