const pool = require('../db');
const crypto = require('crypto');
const addpatient = async (req, res , next ) => {
try{
    const { numcart, firstName, lastName, birthDate, gender, phone, email, consultationReason } = req.body;

    if (!numcart || !firstName || !lastName || !birthDate || !gender || !phone || !email || !consultationReason) {
        return res.status(400).json({ message: 'All fields are required' });
    }

  
function generatePassword(length = 10) {
    return crypto.randomBytes(length)
      .toString('base64')
      .replace(/[^a-zA-Z0-9]/g, '')        
      .slice(0, length);
  }
  

  const password = await generatePassword();
    const result = await pool.query(
        "INSERT INTO dossier_patient (numcart, firstName, lastName, birthDate, gender, phone, email, consultationReason , motdepasse) VALUES ($1, $2, $3, $4, $5, $6, $7, $8 ,$9) RETURNING *",
        [numcart, firstName, lastName, birthDate, gender, phone, email, consultationReason , password]         
    );
    await pool.query(
      `INSERT INTO connexion (email, password, role) 
        VALUES ($1, $2, $3)`,
      [email, password, 'patient']
    );

    res.status(201).json({ message: "Patient added successfully", patient: result.rows[0] });
    } catch (error) {
        next(error);
    }
}

const addBilan = async (req, res, next) => {
    try {
      const {
        numcart,
        nom,
        prenom,
        hb, gb, plq, uree, creat, na, k,
        calcemie, phosphore, pth, acideUrique,
        proteinurie, hematurie, leucocyturie
      } = req.body;
  
      const result = await pool.query(
        `INSERT INTO bilan_patient (
          numcart, nom, prenom, hb, gb, plq, uree, creat, na, k,
          calcemie, phosphore, pth, acideUrique, proteinurie, hematurie, leucocyturie
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
          $11, $12, $13, $14, $15, $16, $17
        ) RETURNING *`,
        [
          numcart, nom, prenom, hb, gb, plq, uree, creat, na, k,
          calcemie, phosphore, pth, acideUrique, proteinurie, hematurie, leucocyturie
        ]
      );
  
      res.status(201).json({ success: true, message: "Bilan ajouté", data: result.rows[0] });
    } catch (error) {
      next(error);
    }
  };

const getLastBilanByNumCart = async (req, res) => {
  const { numcart } = req.params;

  try {
    const result = await pool.query(
     "SELECT * FROM bilan_patient  WHERE numcart = $1 ORDER BY numcart DESC LIMIT 1",
      [numcart]
    );

    if (result.rows.length === 0) {
      return res.json({ success: false, message: "Patient non trouvé" });
    }

    return res.json({ success: true, bilan: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Erreur serveur" });
  }
};

  
    
  const getPatientsLast24h = async (req, res) => {
    try {
      const result = await pool.query(
      `SELECT * FROM dossier_patient
   WHERE created_at >= NOW() - INTERVAL '24 hours'
   ORDER BY is_prioritaire DESC, created_at ASC`
      );
      res.json({ success: true, patients: result.rows });
      console.log(result.rows)
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, message: "Erreur serveur" });
    }
  };
  const setPrioritaire = async (req, res) => {
    const { numcart } = req.params;
  
    try {
      await pool.query(
        "UPDATE dossier_patient SET is_prioritaire = true WHERE numcart = $1",
        [numcart]
      );
  
      res.json({ success: true, message: "Patient set as prioritaire" });
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: "Failed to update priority" });
    }
  };
  const removePriority = async (req, res) => {
    const { numcart } = req.params;
  
    try {
      await pool.query(
        "UPDATE dossier_patient SET is_prioritaire = false WHERE numcart = $1",
        [numcart]
      );
  
      res.json({ success: true, message: "Patient dépriorisé" });
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, message: "Erreur serveur" });
    }
  };
  const getinfopatient = async (req, res) => {
    const { numcart } = req.params;
  
    try {
      const result = await pool.query(
        "SELECT * FROM dossier_patient WHERE numcart = $1",
        [numcart]
      );
  
      if (result.rows.length === 0) {
        return res.status(404).json({ message: "Patient non trouvé" });
      }
  
      res.json({success: true, patient: result.rows[0] });
    } catch (error) {
      console.error("Erreur lors de la récupération des informations patient:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  };
module.exports = {
  addpatient,
  addBilan,
  getLastBilanByNumCart,
    getPatientsLast24h,
    setPrioritaire ,
    removePriority, 
    getinfopatient
};




