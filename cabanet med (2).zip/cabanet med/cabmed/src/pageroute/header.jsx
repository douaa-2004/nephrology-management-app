import React from "react";
import "../css/header.css"; // Chemin correct pour header.css dans src/css/

const Header = () => {
  return (
    <header className="header">
      <img src="/img/image.jpg" alt="Nephrology Clinic Logo" className="header-logo" />
      <div className="header-text">
        <h3>Dr. Neggaz <i className="fas fa-stethoscope" style={{ fontSize: '14px', color: '#3f94e4' }}></i></h3>
        <span>Nephrology Medical Clinic</span>
      </div>
    </header>
  );
};

export default Header;