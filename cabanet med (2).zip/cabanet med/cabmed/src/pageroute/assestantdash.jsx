import { useState } from "react";
import '../css/assestant.css'
import Assestantnav from "../component/assestantnav";
import {BrowserRouter , Routes , Route } from 'react-router-dom'
import Dossier from "../component/assestant/credossier";
import Billan from "../component/assestant/creebillan";
import Motdepasse from "../component/assestant/motdepass";
  import PatientsList from "../component/assestant/prioritaire";
  export default function Assestantdash() {
    return (
      <div>
        <Assestantnav />
        <Routes>
          <Route path='creedossier' element={<Dossier/>} />
          <Route path = "creebillan" element ={<Billan/>}/>
          <Route path="motdepass" element={<Motdepasse/>} />
          <Route path="prioritaire" element={<PatientsList/>} />
        </Routes>
      </div>
    )
  }
  
        
          
