import { useDispatch, useSelector } from "react-redux";
import { signinsuccess, signInfailure } from "../../redux/user/userslice";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "../css/singup.css"; // Corrigez en "../css/signup.css" si vous renommez le fichier

const Login = () => {
  const [email, setEmail] = useState("");
  const [motdepasse, setMotdepasse] = useState("");
  const [error, setError] = useState(null);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { currentUser } = useSelector((state) => state.user);

  useEffect(() => {
    if (currentUser) {
      switch (currentUser.role) {
        case "medcin":
          navigate("/admindash");
          break;
        case "assestant":
          navigate("/assestant");
          break;
        case "patient":
          navigate("/patient");
          break;
        default:
          navigate("/");
      }
    }
  }, [currentUser, navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: motdepasse }),
      });

      const data = await res.json();

      if (res.ok) {
        dispatch(signinsuccess(data));
        setError(null);
      } else {
        dispatch(signInfailure(data.message || "Erreur d'identification"));
        setError(data.message || "Email ou mot de passe incorrect");
      }
    } catch (err) {
      dispatch(signInfailure("Erreur serveur"));
      setError("Erreur serveur");
    }
  };

  return (
    <div className="login-page"> {/* Ajout de la classe login-page pour le centrage */}
      <form onSubmit={handleLogin} className="signupform">
        <div className="maintitle">
          <div>Login</div>
          <h4>Saisissez vos identifiants pour accéder à votre compte</h4>
        </div>
        <input
          type="email"
          placeholder="E-mail Address"
          required
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          required
          onChange={(e) => setMotdepasse(e.target.value)}
        />
        <button className="button" type="submit">Login</button>
        {error && <p className="error">{error}</p>} {/* Remplacé le style inline par une classe */}
      </form>
    </div>
  );
};

export default Login;