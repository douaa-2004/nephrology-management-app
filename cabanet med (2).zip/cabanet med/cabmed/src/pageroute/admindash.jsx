import Adminnav from "../component/adminnav";
import FicheClinique from "../component/medcin/ficheclinique";
import ModifierFicheClinique from "../component/medcin/updatefiche";
import Consultation from "../component/medcin/consultation";
import PreConsultation from "../component/medcin/preconsultation";
import ConsulterFicheClinique from "../component/medcin/ConsulterFicheClinique";
import { Routes, Route } from 'react-router-dom';
import ConsulterBilan from "../component/medcin/consulterbillan";
import ConduitePatient from "../component/medcin/conduite";
import OrdonnancePreview from "../component/medcin/ordenence";
import ExamPDFForm from "../component/medcin/examradiolo";
import Consulterrapport from "../component/medcin/consulterapport";
import MedicalReportForm from "../component/medcin/validerrapport";
import Add_assestant from "../component/medcin/add_assestant";
import Exambiolo from "../component/medcin/exambiolo";

export default function Admindash() {
  return (
    <div>
      
      <Adminnav/>
      
      <Routes>
       
        <Route path="ficheclinique" element={<FicheClinique />} />
        <Route path="mettreajour" element={<ModifierFicheClinique />} />
        <Route path="preconsultation" element={<PreConsultation />} />
        <Route path="consultation" element={<Consultation />} />
        <Route path="fiche-clinique" element={<ConsulterFicheClinique />} />
        <Route path="consulterbilans" element={<ConsulterBilan />} />
        <Route path="conduite" element={<ConduitePatient />} />
        <Route path="ordenence" element={<OrdonnancePreview />} />    
        <Route path="demande-radiologique" element={<ExamPDFForm />} />
        <Route path="demande-biologique" element={<Exambiolo />} />
        <Route path="consulter-rapport" element={<Consulterrapport />} />
        <Route path="validerrapport" element={<MedicalReportForm />} /> 
        <Route path="add_assestant" element={<Add_assestant />} />
    
      </Routes>
    </div>
  );
}
