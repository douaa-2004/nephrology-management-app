import Patientnav from "../component/patient/patientnav";
import Rapportpatient from "../component/patient/Rapportpatient";
import { Routes, Route } from 'react-router-dom';
import { useEffect } from "react";

export default function Patientdash() {
  return (
    <>
      <Patientnav />
      <div style={{ margin:"0",

        padding: "0",
        fontFamily: "Cairo, sans-serif" }}>
        <Routes>
          <Route
            path="/"
            element={
              <div style={{ textAlign: "center", marginTop: "60px" }}>
                <h1 style={{ color: "#1A76D1", fontSize: "36px", marginBottom: "20px" }}>
                  Bienvenue dans votre espace patient
                </h1>
                <p style={{ fontSize: "18px", color: "#555", maxWidth: "700px", margin: "0 auto" }}>
                  Ici, vous pouvez facilement :
                </p>
                <ul style={{ listStyle: "none", padding: "0", marginTop: "30px", fontSize: "18px", color: "#333" }}>
                  <li style={{ marginBottom: "15px" }}>📄 Consulter et télécharger votre <strong>rapport médical</strong>.</li>
                  <li style={{ marginBottom: "15px" }}>🔍 Voir les <strong>examens demandés</strong> par votre médecin.</li>
                    <li style={{ marginBottom: "15px" }}>📞 Contacter votre <strong>médecin</strong> pour toute question.</li>
                </ul>
                <p style={{ marginTop: "40px", color: "#777" }}>
                  Utilisez le menu à gauche pour naviguer entre les différentes sections.
                </p>
              </div>
            }
          />
          <Route path="rapport" element={<Rapportpatient/>} />
        </Routes>
      </div>
    </>
  );
}
