
import MAINHOME from "./mainhome"
export default function HOME(){
    return(
  
<>

<MAINHOME/>
</>

    
    )
}