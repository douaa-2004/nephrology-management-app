import "../css/mainhome.css";
import { Link } from "react-router-dom";
export default function MAINHOME() {
  return (
    <>
	  <nav className="navbar">
    <div className="lognavhome">clinique elnadjeh </div>
    <div className="authentication">
     <Link className="link" to={"/login"} > <div className="login">connexion</div></Link>
    </div>
</nav>
      <main className="mainhome">
        <div className="text">
          <h1>
            We Provide <span>Medical</span> Services That You Can <span>Trust!</span>
          </h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sed nisl pellentesque,
            faucibus libero eu, gravida quam.
          </p>
          <div className="buttons">
            <a href="#" className="btn">
              Contact us
            </a>
            <a href="#" className="btn primary">
              About
            </a>
          </div>
        </div>

        <div className="schedule-inner">
          <div className="row">
            <div className="firstcard">
              <div className="single-schedule first">
                <div className="inner">
                  <div className="icon">
                    <i className="fa fa-ambulance"></i>
                  </div>
                  <div className="single-content">
                    <span>Lorem Amet</span>
                    <h4>Emergency Cases</h4>
                    <p>
                      Lorem ipsum sit amet consectetur adipiscing elit. Vivamus et erat in lacus
                      convallis sodales.
                    </p>
                    <a href="#">
                      LEARN MORE<i className="fa fa-long-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="secondcard">
              <div className="single-schedule middle">
                <div className="inner">
                  <div className="icon">
                    <i className="icofont-prescription"></i>
                  </div>
                  <div className="single-content">
                    <span>Fusce Porttitor</span>
                    <h4>Doctors Timetable</h4>
                    <p>
                      Lorem ipsum sit amet consectetur adipiscing elit. Vivamus et erat in lacus
                      convallis sodales.
                    </p>
                    <a href="#">
                      LEARN MORE<i className="fa fa-long-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="thirdcard">
              <div className="single-schedule last">
                <div className="inner">
                  <div className="icon">
                    <i className="icofont-ui-clock"></i>
                  </div>
                  <div className="single-content">
                    <span>Donec luctus</span>
                    <h4>Opening Hours</h4>
                    <ul className="time-sidual">
                      <li className="day">
                        Monday - Friday <span>8.00-20.00</span>
                      </li>
                      <li className="day">
                        Saturday <span>9.00-18.30</span>
                      </li>
                      <li className="day">
                        Monday - Thursday <span>9.00-15.00</span>
                      </li>
                    </ul>
                    <a href="#">
                      LEARN MORE<i className="fa fa-long-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
<section className="services-section" id="services">
  <div className="services-container">
    <div className="services-header">
      <h2>We Offer Different Services To Improve Your Health</h2>
      <img src="img/section-img.png" alt="#" />
      <p>
        Lorem ipsum dolor sit amet consectetur adipiscing elit praesent aliquet. pretiumts
      </p>
    </div>

    <div className="services-grid">
      {[
        { icon: "prescription", title: "General Treatment" },
        { icon: "tooth", title: "Teeth Whitening" },
        { icon: "heart-alt", title: "Heart Surgery" },
        { icon: "listening", title: "Ear Treatment" },
        { icon: "eye-alt", title: "Vision Problems" },
        { icon: "blood", title: "Blood Transfusion" },
      ].map((service, idx) => (
        <div className="service-card" key={idx}>
          <i className={`icofont icofont-${service.icon}`}></i>
          <h4>
            <a href="service-details.html">{service.title}</a>
          </h4>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus dictum eros ut
            imperdiet.
          </p>
        </div>
      ))}
    </div>
  </div>
</section>

     
    </>
  );
}
