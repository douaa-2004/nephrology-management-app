import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { signinsuccess } from "../../redux/user/userslice"; 
import "../css/adminnav.css";
import Header from "../pageroute/Header";  
export default function Adminnav() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [isSidebarActive, setIsSidebarActive] = useState(false);

  const handleLogout = () => {
    dispatch(signinsuccess(null)); 
    navigate("/");
  };

  return (
    <>
      <Header />
      <button
        className="toggle-button"
        onClick={() => setIsSidebarActive(!isSidebarActive)}
      >
        ☰
      </button>
      <nav className={`sidebar ${isSidebarActive ? "active" : ""}`}>
        <ul>
          <li>
            <Link to="/admindash/ficheclinique">
              <i className="fas fa-file-medical"></i> Créer fiche clinique
            </Link>
          </li>
          <li>
            <Link to="/admindash/mettreajour">
              <i className="fas fa-edit"></i> Mettre à jour la fiche clinique
            </Link>
          </li>
          <li>
            <Link to="/admindash/preconsultation">
              <i className="fas fa-stethoscope"></i> Consultation de patient
            </Link>
          </li>
          <li>
            <Link to="/admindash/consulter-rapport">
              <i className="fas fa-clipboard-list"></i> Consulter les demandes de rapports
            </Link>
          </li>
          <li>
            <Link to="/admindash/add_assestant">
              <i className="fas fa-user-plus"></i> Ajouter des assistants
            </Link>
          </li>
        </ul>
        <button className="logout-button" onClick={handleLogout}>
          <i className="fas fa-sign-out-alt"></i> Se déconnecter
        </button>
      </nav>
    </>
  );
}