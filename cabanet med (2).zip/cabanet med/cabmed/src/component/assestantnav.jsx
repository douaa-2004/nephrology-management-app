import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { signinsuccess } from "../../redux/user/userslice";
import "../css/adminnav.css";
import Header from "../pageroute/Header";

export default function Assistantnav() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [isSidebarActive, setIsSidebarActive] = useState(false);

  const handleLogout = () => {
    dispatch(signinsuccess(null)); // Reset user state
    navigate("/");
  };

  return (
    <>
      <Header />
      <button
        className="toggle-button"
        onClick={() => setIsSidebarActive(!isSidebarActive)}
      >
        ☰
      </button>
      <nav className={`sidebar ${isSidebarActive ? "active" : ""}`}>
        <ul className="sidebar-list">
          <li>
            <Link to="/assestant/creedossier">
              <i className="fas fa-folder-plus"></i> Créer le dossier patient
            </Link>
          </li>
          <li>
            <Link to="/assestant/creebillan">
              <i className="fas fa-file-invoice"></i> Créer le bilan
            </Link>
          </li>
          <li>
            <Link to="/assestant/prioritaire">
              <i className="fas fa-exclamation-triangle"></i> Traitement de priorité
            </Link>
          </li>
        </ul>
        <button className="logout-button" onClick={handleLogout}>
          <i className="fas fa-sign-out-alt"></i> Se déconnecter
        </button>
      </nav>
    </>
  );
}