import React, { useState } from "react";
import "../../css/Login.css";

const Add_assestant = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/medcin/add_assestant", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      if (response.ok) {
        setMessage("Assistant ajouté avec succès !");
        setEmail("");
        setPassword("");
      } else {
        setMessage(`Erreur: ${data.message}`);
      }
    } catch (error) {
      console.error("Erreur:", error);
      setMessage("Une erreur s'est produite.");
    }
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2 className="patients-title">Ajouter un Assistant</h2>
          <form className="signupform" onSubmit={handleSubmit}>
            <input
              type="email"
              placeholder="E-mail Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Mot de passe"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button className="btn-action" type="submit">Ajouter</button>
            {message && (
              <p
                style={{ color: "#1A76D1", fontSize: "16px", marginTop: "10px" }}
                className="message"
              >
                {message}
              </p>
            )}
          </form>
          <h4>Ajoutez un assistant pour vous aider dans votre travail</h4>
        </div>
      </div>
    </div>
  );
};

export default Add_assestant;