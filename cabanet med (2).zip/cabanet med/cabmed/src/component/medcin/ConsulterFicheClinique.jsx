import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import "../../css/consulterdficheq.css";

export default function ConsulterFicheClinique() {
  const location = useLocation();
  const { numcart } = location.state || {};

  const [fiche, setFiche] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch patient data
  useEffect(() => {
    if (numcart) {
      fetch(`http://localhost:5000/api/medcin/fiche-clinique/${numcart}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success) setFiche(data.fiche);
          setLoading(false);
        })
        .catch((err) => {
          console.error(err);
          setLoading(false);
        });
    }
  }, [numcart]);

  // Print entire window content
  const handlePrint = () => {
    window.print(); // This will trigger the print dialog for the whole page
  };

  if (loading) return <p>Chargement...</p>;
  if (!fiche) return <p style={{
    fontSize: "50px",
    marginTop: "200px",
    textAlign: "center",
    color: "#1A76D1",
    width: "100%",
  }}>Aucune fiche trouvée.</p>;

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <div className="fiche-header">
            <h2>🧾 Fiche Clinique du Patient</h2>
            <p>Numéro Carte : <strong>{numcart}</strong></p>
          </div>

          <div className="fiche-block">
            <h3>Informations Générales</h3>
            <p><strong>Nom :</strong> {fiche.lastname}</p>
            <p><strong>Prénom :</strong> {fiche.firstname}</p>
            <p><strong>Date de naissance :</strong> {new Date(fiche.birthdate).toLocaleDateString()}</p>
            <p><strong>Sexe :</strong> {fiche.sexe}</p>
          </div>

          <div className="fiche-block">
            <h3>Antécédents</h3>
            <p><strong>Médicaux :</strong><br />{fiche.ant_med}</p>
            <p><strong>Chirurgicaux :</strong><br />{fiche.ant_chir}</p>
            {fiche.sexe === "Femme" && (
              <p><strong>Gynéco-obstétricaux :</strong><br />{fiche.ant_gyneco}</p>
            )}
            <p><strong>Familiaux :</strong><br />{fiche.ant_familiaux}</p>
          </div>

          <div className="fiche-block">
            <h3>Habitudes de vie</h3>
            <p>{fiche.habitudes}</p>
          </div>

          <div className="fiche-block">
            <h3>Examen Clinique</h3>
            <p>{fiche.examen_clinique}</p>
          </div>
        </div>
      </div>
    </div>
  );
}