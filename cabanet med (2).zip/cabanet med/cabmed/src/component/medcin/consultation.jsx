import React from "react";
import { useNavigate } from "react-router-dom";
import "../../css/consultation.css"; 
import { FaFileMedical, FaVials, FaNotesMedical, FaPrescriptionBottle, FaXRay, FaFlask } from "react-icons/fa";
import { useLocation } from "react-router-dom";
const actions = [
  {
    title: "Fiche clinique",
    path: "/admindash/fiche-clinique",
    icon: <FaFileMedical />,
    description: "Voir ou modifier la fiche clinique du patient",
  },
  {
    title: "Bilans",
    path: "/admindash/consulterbilans",
    icon: <FaVials />,
    description: "Consulter les bilans biologiques",
  },
  {
    title: "Conduite à tenir",
    path: "/admindash/conduite",
    icon: <FaNotesMedical />,
    description: "Ajouter les recommandations du médecin",
  },
  {
    title: "Prescription",
    path: "/admindash/ordenence",
    icon: <FaPrescriptionBottle />,
    description: "Rédiger une ordonnance médicale",
  },
  {
    title: "Examen radiologique",
    path: "/admindash/demande-radiologique",
    icon: <FaXRay />,
    description: "Demander un examen d’imagerie",
  },
  {
    title: "Bilan biologique",
    path: "/admindash/demande-biologique",
    icon: <FaFlask />,
    description: "Sélectionner les bilans nécessaires",
  },
];

export default function Consultation() {
  const navigate = useNavigate();
  const location = useLocation();
  const { numcart } = location.state || {};
  return (
    <div className="actions-page">
      <h2 className="actions-title">🩺 Actions du Médecin</h2>
      <div className="actions-grid">
        {actions.map((action, index) => (
          <div key={index} className="action-card" onClick={() => navigate(action.path, { state: { numcart } })}>
          
            <div className="icon">{action.icon}</div>
            <h3 className="card-title">{action.title}</h3>
            <p className="card-desc">{action.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}