import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import "../../css/conduite.css";

export default function ConduitePatient() {
  const location = useLocation();
  const { numcart } = location.state || {};
  const [historique, setHistorique] = useState([]);
  const [texte, setTexte] = useState("");

  useEffect(() => {
    if (numcart) {
      fetch(`http://localhost:5000/api/medcin/conduite/${numcart}`)
        .then(res => res.json())
        .then(data => setHistorique(data))
        .catch(err => console.error("Erreur lors du chargement:", err));
    }
  }, [numcart]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!texte.trim()) return;

    fetch(`http://localhost:5000/api/medcin/conduite/${numcart}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ texte })
    })
      .then(res => res.json())
      .then(newEntry => {
        setHistorique([newEntry, ...historique]);
        setTexte("");
      });
  };

  return (
    <div className="conduite-container">
      <h2 className="conduite-title">Conduite à tenir</h2>

      <form onSubmit={handleSubmit} className="conduite-form">
        <textarea
          value={texte}
          onChange={(e) => setTexte(e.target.value)}
          placeholder="Rédiger ici l'évolution ou la décision médicale..."
        />
        <button type="submit">Ajouter</button>
      </form>

      <div className="conduite-historique">
        {historique.map((item) => (
          <div key={item.id} className="conduite-note">
            <span className="conduite-date">
              {new Date(item.created_at).toLocaleString()}
            </span>
            <p>{item.texte}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
