import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../css/preconsultation.css"; 

export default function PreConsultation() {
  const [numcart, setNumcart] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleCheck = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/medcin/check-patient/${numcart}`);
      const data = await res.json();

      if (data.exists) {
        navigate("/admindash/consultation", { state: { numcart } });
      } else {
        setError("Numéro de carte invalide ou patient non trouvé.");
      }
    } catch (err) {
      console.error("Erreur lors de la vérification :", err);
      setError("Erreur de serveur");
    }
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2>🔍 Vérifier le patient avant consultation</h2>
          <div className="preconsultation-form">
            <input
              type="text"
              placeholder="Entrer le numéro de carte"
              value={numcart}
              onChange={(e) => setNumcart(e.target.value)}
            />
            <button onClick={handleCheck}>Vérifier</button>
            {error && <p>{error}</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
