// RapportForm.js
import  {  useState } from "react";

import {  useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useRef } from "react";

import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";





import LastBilan from "./lastbilan";




export default function RapportForm({ onSubmit }) {
  const location = useLocation();
  const { numcart } = location.state || {};
 const [showPopup, setShowPopup] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);

   const handleInput = (e) => {
  e.target.style.height = "auto";
  e.target.style.height = e.target.scrollHeight + "px";
};

   ;

  const [formData, setFormData] = useState({
    description : "",
    antecedents_med: "",
    antecedents_chiru: "",
    habitudes: "",
    antecedents_familiaux: "",
    serologie: "",
    vaccination: "",
    catheter: "",
    fistule: "",
    transfusion: "",
    projet_greffe: "",
    groupage: "",
    poids_sec : "",
    hemodialyseur: "",
    heparinisation: "",
    poids_interdialytique: "",
    conductivité : "",
    temperature_bain:"",
    bain_de_dialyse : "",
    pompe : "",
    echocardiographie: "",
    echographie_abdominale: "",
    doppler: "",
    evolution: "",
    traitement_actuel: ""
  });
  const pdfRef = useRef();

 const section1Ref = useRef();
  const section2Ref = useRef();
  const section3Ref = useRef();
  const section4Ref = useRef()
  

const generatePDF = async () => {
    const pdf = new jsPDF("p", "mm", "a4");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const marginX = 10; 

    const renderSection = async (ref, isFirstPage = false) => {
      const canvas = await html2canvas(ref.current, { scale: 2 });
      const imgData = canvas.toDataURL("image/png");
      const imgWidth = pageWidth - 2 * marginX;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;
      const topMargin = 15;
      if (!isFirstPage) pdf.addPage();
      pdf.addImage(imgData, "PNG", marginX, topMargin, imgWidth, imgHeight);

      heightLeft -= pageHeight;
      while (heightLeft > 0) {
        position -= pageHeight;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", marginX, position + topMargin, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
    };

    await renderSection(section1Ref, true);
    await renderSection(section2Ref);
    await renderSection(section3Ref);
    await renderSection(section4Ref);
  

    pdf.save("rapport.pdf");



     try {
    const pdfBlob = pdf.output("blob");
    const formData = new FormData();
    const pdfFile = new File([pdfBlob], "rapport.pdf", {
      type: "application/pdf",
    });
    formData.append("pdfFile", pdfFile);
    formData.append("numcart", numcart);

    const response = await fetch("http://localhost:5000/api/drive/upload", {
      method: "POST",
      body: formData,
     
    });

    const data = await response.json();
    if (response.ok) {
      setUploadStatus(`Fichier téléchargé : ${data.link}`);
       setShowPopup(true);
    } else {
      setUploadStatus(` Échec : ${data.message}`);
    }
  } catch (error) {
    console.error("Erreur lors de l'upload vers Google Drive :", error);  
    setUploadStatus(" Une erreur s'est produite.");
  }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
    const closePopup = () => {
    setShowPopup(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };


  useEffect(() => {
    const fetchdata = async () => {
      try {
        const res = await fetch(`http://localhost:5000/api/medcin/get-fiche-clinique/${numcart}`);
        const data = await res.json();
        if (data.success && data.fiche) {
          setFormData((prev) => ({
            ...prev,
            antecedents_med: data.fiche.ant_med,
            antecedents_chiru: data.fiche.ant_chir,
            habitudes: data.fiche.habitudes,
            antecedents_familiaux: data.fiche.ant_familiaux,

          }));
        }
        console.log(data);

      } catch (err) {
        console.error(err);
      }
    };
  
    if (numcart) {
      fetchdata();
    }
  }, [numcart]);
  


  
const popupOverlayStyle = {
  position: "fixed",
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: "rgba(0, 0, 0, 0.5)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  zIndex: 9999,
};

const popupStyle = {
  backgroundColor: "white",
  padding: "30px",
  borderRadius: "12px",
  textAlign: "center",
  boxShadow: "0px 0px 15px rgba(0, 0, 0, 0.3)",
};

  return (
    <>
   <div className="conti"
   style={{
    
    display:"flex",
    justifyContent:'center',
    alignItems:"center", 

   }}
   
   >

    <form
  action=""
  style={{
    width: "900px",
    margin:"100px 0",
    marginLeft :"150px",
    display: "flex",
    flexDirection: "column", 
    alignItems: "center",
  }}
>
  <h1 
  style={{
    textAlign: "center",
    fontSize: "30px",
    marginBottom: "50px",
    color: "#1A76D1",
  }}
  >remplir les Informations</h1>
  <div style={{ width: "100%" ,
    maxWidth: "900px",
    
   }}>
    <label
      htmlFor="description"
      style={{
        display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",
      }}
    >
      Description
    </label>
    <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="description"
      style={{
        width: "100%",
        minHeight: "100px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
  <div 
  style={{
    marginTop: "30px",
    width: "900px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "20px",
  }} >
    <div
    style={{
      flex: "1",
    }}
    >
      <label htmlFor="serologie"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >serologie</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="serologie"
      style={{
        width: "100%",
        minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
       <div style={{
     flex: "1",
    }} >
      <label htmlFor="vaccination"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >vaccination</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="vaccination"
      style={{
        width: "100%",
        minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>   
    <div  style={{
      flex: "1",
    }}>
      <label htmlFor="catheter"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >catheter</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="catheter"
      style={{
        width: "100%",
        minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
  
  </div>
  <div style={{ width: "100%" ,
    maxWidth: "900px",
    marginTop: "50px",
   }}>
    <label
      htmlFor="fistule"
      style={{
        display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",
      }}
    >
      fistule rterio-veineuse
    </label>
    <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="fistule"
      id="fistule"
      style={{
        width: "100%",
        minHeight: "100px",
        height: "auto",
        resize: "none",
        padding: "10px",
        fontSize: "16px",
        overflow: "hidden",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
   <div 
  style={{
    marginTop: "50px",
    width: "900px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "20px",
  }} >
    <div
    style={{
      flex: "1",
    }}
    >
      <label htmlFor="transfusion"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >transfusion</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="transfusion"
      style={{
        width: "100%",
        minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
       <div style={{
     flex: "1",
    }} >
      <label htmlFor="greffe"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >greffe</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="projet_greffe"
      style={{
        width: "100%",
        minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>   
    <div  style={{
      flex: "1",
    }}>
      <label htmlFor="groupage"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >groupage</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="groupage"
      style={{
        width: "100%",
        minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
  </div>
  
  <div 
  
  style={{
position : "relative",
    border: "4px solid #1A76D1",
    padding: "20px",
    borderRadius: "10px",
    marginTop: "50px",
  }}> 
  <h1 
  style={{
    textAlign: "center",
    fontSize: "30px",
    marginTop: "50px",
    color: "#1A76D1",
    backgroundColor: "white",

    position: "absolute",
    top: "-70px",
    left: "50%",
    transform: "translateX(-50%)",
    padding: "0 20px",
  }}
  >paramatre de dialyse</h1>
    <div 
  style={{
    marginTop: "50px",
    width: "900px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "20px",
  }} >
    <div
    style={{
      flex: "1",
    }}
    >
      <label htmlFor="poids_sec"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      > poids sec</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="poids_sec"
      style={{
        width: "100%",
         minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
       <div style={{
     flex: "1",
    }} >
      <label htmlFor="hemodialyseur"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >
      hemodialyseur</label>
      
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="hemodialyseur"
      style={{
        width: "100%",
         minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>   
    <div  style={{
      flex: "1",
    }}>
      <label htmlFor="heparinisation"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >heparinisation</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="heparinisation"
      style={{
        width: "100%",
         minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
    
  </div>
   <div 
  style={{
    marginTop: "20px",
    width: "900px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "20px",
  }} >
    <div
    style={{
      flex: "1",
    }}
    >
      <label htmlFor="poids interdialytique"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >poids interdialytique</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="poids_interdialytique"
      style={{
        width: "100%",
         minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
       <div style={{
     flex: "1",
    }} >
      <label htmlFor="conductivité"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >conductivité</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="conductivité"
      style={{
        width: "100%",
         minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>   
    <div  style={{
      flex: "1",
    }}>
      <label htmlFor="temperature_bain"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >température du bain</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="temperature_bain"
      style={{
        width: "100%",
         minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
    
  </div>
   <div 
  style={{
    marginTop: "20px",
    width: "900px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "20px",
  }} >
    <div
    style={{
      flex: "1",
    }}
    >
      <label htmlFor="bain_de_dialyse"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >bain de dialyse</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="bain_de_dialyse"
      style={{
        width: "100%",
         minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
    </div>
       <div style={{
     flex: "1",
    }} >
      <label htmlFor="pompe"
      style={{ display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",}}
      >pompe</label>
          <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="pompe"
      style={{
        width: "100%",
        minHeight: "10px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
    </div>
  </div>
   
   <div style={{ width: "100%" ,
    maxWidth: "900px",
    marginTop: "50px",
    
   }}>
    <label
      htmlFor="echocardiographie"
      style={{
        display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",
      }}
    >
      echocardiographie
    </label>
    <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="echocardiographie"
      style={{
        width: "100%",
        minHeight: "100px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
   <div style={{ width: "100%" ,
    maxWidth: "900px",
    marginTop: "50px",
    
   }}>
    <label
      htmlFor="echographie_abdominale"
      style={{
        display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",
      }}
    >
echocaechographie abdominale    </label>
    <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="echographie_abdominale"
      style={{
        width: "100%",
        minHeight: "100px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
  <div style={{ width: "100%" ,
    maxWidth: "900px",
    marginTop: "50px",
    
   }}>
    <label
      htmlFor="doppler"
      style={{
        display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",
      }}
    >
      echo doppler du mebmre superieur gauche 
    </label>
    <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="doppler"
      style={{
        width: "100%",
        minHeight: "100px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
  <div style={{ width: "100%" ,
    maxWidth: "900px",
    marginTop: "50px",
    
   }}>
    <label
      htmlFor="evolution"
      style={{
        display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",
      }}
    >
      evolution
    </label>
    <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="evolution"
      style={{
        width: "100%",
        minHeight: "100px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
  <div style={{ width: "100%" ,
    maxWidth: "900px",
    marginTop: "50px",
    
   }}>
    <label
      htmlFor="traitement_actuel"
      style={{
        display: "block",
        marginBottom: "10px",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#1A76D1",
      }}
    >
      traitement actuel
    </label>
    <textarea
      
      onInput={handleInput}
      onChange={handleChange}
      type="text"
      name="traitement_actuel"
      style={{
        width: "100%",
        minHeight: "100px",
        resize: "none",
        overflow: "hidden",
        padding: "10px",
        fontSize: "16px",
        border: "1px solid #1A76D1",
        borderRadius: "5px",
        outline: "none",
      }}
    />
  </div>
</form>
   </div>

    <div 
    ref= {pdfRef}
    className="rapport"  style={{
      pageBreakInside: "avoid",
      
       padding: "30px",
       width: "210mm",
       margintop: "50px",
       fontSize: "13px",
       margin: "auto",
       backgroundColor: "#f9f9f9"
    }} >
    <div ref={section1Ref}  >
        <div className="info-medcin" 
      style={{  
        display: "flex",
        flexDirection: "column",
        gap: "10px",
      }}

      >
        <div className="premier-line" style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          

        }} >
        <h2>clinique Elnadjeh</h2>
        <h2>oran le :{new Date().toLocaleDateString() }</h2>
        </div>
        <h2>Dr Med Seghir Nekkache</h2>
        <h2>Medecin Nephrologue</h2>
        <h2>Tel: 0555 555 555</h2>

      </div>
      <h1 
      style={{
        textAlign: "center",
        fontSize: "25px",
        marginTop: "30px",
        color: "#1A76D1",
      }}
      >  RAPPORT MEDICAL</h1>
      <div className="description"
      style={{ 
        wordWrap: "break-word", 
        maxWidth: "100%",       
        fontSize: "20px",
        fontWeight: "bold",
        marginTop: "30px"
      }} >
        {formData.description}
      </div>
      <div className="antecedents"
      style={{
        marginTop: "30px",
        fontSize: "20px",
       color: "black",
      
      }} >
        <h1  
        style={{
          fontSize: "25px",
          
          color: "#1A76D1",
          
        }}

        >Antécédents personnels : </h1>
         <p
        style={{
          fontSize: "20px",
          fontWeight : "500",
           marginTop: "10px"}}
         >- medicaux : {formData.antecedents_med}</p>
          <p
           style={{
            fontSize: "20px",
            fontWeight : "500",
             marginTop: "10px"}}
          >- chirurgicaux : {formData.antecedents_chiru}</p>
          <p
           style={{
            fontSize: "20px",
            fontWeight : "500",
             marginTop: "10px"}}
          >- habitudes : {formData.habitudes}</p>
 <h1  
        style={{
          fontSize: "25px",
          marginTop: "30px",
          color: "#1A76D1",
          
        }}

        >Antécédents Familiaux :  </h1>
          <p
          style={{
            whiteSpace: "pre-wrap", 
            fontSize: "20px",
            fontWeight : "500",
             marginTop: "10px",
             lineHeight: "0.7",
             }} 
          >{formData.antecedents_familiaux}</p>
          <div>
           <p
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "20px",
               color: "#1A76D1",
               display: "inline-block",
               }}

            >serologie :  </p>  {formData.serologie}
          </div>
          <div>
             <p
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "20px",
               color: "#1A76D1",
               display: "inline-block",
               }}

            >catheter de voie centrale :   </p>{formData.catheter}
          </div>
          <div style={{
            color:'black'
          }} >
            <p
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "20px",
               color: "#1A76D1",
               display: "inline-block",
               }}

            >vaccination :   </p> {formData.vaccination}
          </div>
          <div>
            <p  
            style={{ whiteSpace: "pre-wrap",
              
            }}

            > <span
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "20px",
               color: "#1A76D1",
               display: "block",
              
               
             
               }}

            >fistule rterio-veineuse :  </span> {formData.fistule} </p>
          </div>
    </div>
  
   
    </div>
         <div ref={section2Ref} >  
            <div style={{
              fontSize: "20px",
            }} > <p
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "30px",
               color: "#1A76D1",
                display: "inline-block",     
               }}
            >transfusion :  </p > {formData.transfusion} </div>
          
            <div
            style={{
              fontSize: "20px",
            }}
            > <p
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "20px",
               color: "#1A76D1",
               display: "inline-block",
               }}

            >Projet de greffe:  </p> {formData.projet_greffe} </div>
         
            <div style={{

              fontSize: "20px",
            }} > <p
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "20px",
               color: "#1A76D1",
               display: "inline-block",
               }}

            >groupage :  </p> {formData.groupage} </div>
          
          <div 
          style={{
            display:"flex",
            flexDirection: "column",


          }}
          >
            <p
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "20px",
               color: "#1A76D1",
               display: "inline-block",
               
               }}

            >parametre de dialyse  : </p> 
             <p
            style={{
              fontSize: "20px",
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- poids sec : {formData.poids_sec}  </p> 
             <p
            style={{
              fontSize: "20px",
             
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- hemodialyseur : {formData.hemodialyseur} </p> 
             <p
            style={{
              fontSize: "20px",
             
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- héparinisation :  {formData.heparinisation} </p> 
             <p
            style={{
              fontSize: "20px",
             
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- poids interdialytique :     {formData.poids_interdialytique}  </p>  
             <p
            style={{
              fontSize: "20px",
             
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- conductivité :  {formData.conductivité} </p> 
            <p
            style={{
              fontSize: "20px",
             
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- temperature du bain : {formData.temperature_bain} </p> 
           <p
            style={{
              fontSize: "20px",
             
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- bain de dialyse :  {formData.bain_de_dialyse}</p>  
            <p
            style={{
              fontSize: "20px",
             
               marginTop: "15px",
               
               display: "inline-block",
               }}

            >- pompe : {formData.pompe}  </p> 

          </div>


                 <div>
            <p  
            style={{ whiteSpace: "pre-wrap",
              lineHeight: "1.7",
              fontSize: "20px",

            }}

            > <span
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "30px",
               color: "#1A76D1",
               display: "block",
              
               
             
               }}

            > echocardiographie :  </span> {formData.echocardiographie} </p>
          </div>
         </div>
          <div ref={section3Ref} >
               <div>
            <p  
            style={{ whiteSpace: "pre-wrap",
              lineHeight: "2",
              fontSize: "20px",
            }}

            > <span
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "30px",
               color: "#1A76D1",
               display: "block",
              
               
             
               }}

            > echocaechographie abdominale :  </span> {formData.echographie_abdominale} </p>
          </div>
            <div>
            <p  
            style={{ whiteSpace: "pre-wrap",
              lineHeight: "2",
              fontSize: "20px",
            }}

            > <span
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "30px",
               color: "#1A76D1",
               display: "block",
              
               
             
               }}

            > echo doppler du mebmre superieur gauche :  </span> {formData.doppler} </p>
          </div>
            
        

           
            <p  
            style={{ whiteSpace: "pre-wrap",
              fontSize: "20px",
            }}

            > <span
            style={{
              fontSize: "20px",
              fontWeight : "bold",
               marginTop: "30px",
               color: "#1A76D1",
               display: "block",
              
               
             
               }}

            > evolution :  </span> {formData.evolution} </p>
          
                 <div  
            style={{ whiteSpace: "pre-wrap",
              fontSize: "20px",
              marginTop: "30px",
              fontWeight: "bold",
              lineHeight: "2",
              
            }}

            > <span
            style={{
              marginBottom: "30px",
              fontSize: "20px",
              fontWeight : "bold",
               color: "#1A76D1",
               display: "block",
              
               
             
               }}

            > traitement actuel :  </span> {formData.traitement_actuel} </div>
          </div>
          <div ref={section4Ref} >
              <p style={
            {
              fontSize: "30px",
              fontWeight : "bold",
               marginTop: "30px",
               color: "#1A76D1",
               display: "block",
              textAlign: "center",
               
             
               }
            
          } > dernier bilan   </p>
            <LastBilan numcartt= {numcart} /> 
          </div>
          
         
          

 
    </div>
    <button onClick={generatePDF} 
     style={{
      display: "block",
     padding: "10px 20px",
     backgroundColor: "#1A76D1",
      color: "white",
      fontSize: "18px",
      margin:"50px auto"
     }}
     >
        Télécharger le rapport PDF
      </button>

        {showPopup && (
        <div style={popupOverlayStyle}>
          <div style={popupStyle}>
            <h2> Fichier Uploadé</h2>
            <p>{uploadStatus}</p>
            <button onClick={closePopup}>Fermer</button>
          </div>
        </div>
      )}
     
    </>
  );
}




