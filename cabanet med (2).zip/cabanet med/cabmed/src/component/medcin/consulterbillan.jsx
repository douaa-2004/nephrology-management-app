import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import "../../css/consultationbillan.css";
import LastBilan from "./lastbilan";

export default function ConsulterBilan({numcartt}) {
  const location = useLocation();
  const { numcart } = location.state || numcartt || {};
  const [bilan, setBilan] = useState(null);
  const [patients, setPatients] = useState([])
  const isRed = (value, rule) => {
    const v = parseFloat(value);
    return isNaN(v) ? false : rule(v);
  };
 useEffect(() => {
    if (!numcart) return;

    fetch(`http://localhost:5000/api/medcin/presedent-bilan/${numcart}`)
      .then((res) => res.json())
      .then((data) => setPatients(data || []))
      .catch((err) => console.error("Erreur lors du fetch du bilan:", err));
  }, [numcart]);
  


  
 
  return (
  <>
     <LastBilan numcartt={numcartt} />

    <div className="patientscontainer " >
 <div className="">
      <h2 className="patientstitle">les billan presedent</h2>
      <div className="tablewrapper">
        <table className="patientstable">
          <thead>
            <tr>
                <th>date</th>
              <th>HB</th>
              <th>GB</th>
              <th>plq</th>
              <th>urée</th>
              <th> créat</th>
              <th>Na+</th>
              <th>K+</th>
              <th>calcémie</th>
              <th>phosphorémie</th>
              <th>PTH</th>
              <th>acide urique</th>
              <th>protéinurie</th>
              <th>hématurie</th>
              <th>leucocyturie</th>
            </tr>
          </thead>
          <tbody>
            {patients.length > 0 ? (
              patients.map((patient) => (
                <tr key={patient.id}>
                  <td>{new Date(patient.created_at).toLocaleDateString()}</td>
                  <td className={isRed(patient.hb, v => v > 8.00) ? "abnormal" : ""}>{patient.hb} g/dl</td>
                  <td>{patient.gb}</td>
                  <td>{patient.plq}</td>
                  <td className={isRed(patient.uree, v => v < 2.00) ? "abnormal" : ""}>{patient.uree} g/l</td>
                  <td className={isRed(patient.creat, v => v < 30.00) ? "abnormal" : ""}>{patient.creat} mg/l</td>
                  <td className={isRed(patient.na, v => v <= 125.00 || v >= 145.00)? "abnormal" : ""}>{patient.na} mmol/l</td>
                  <td className={isRed(patient.k, v => v > 6.00 || v < 3.50) ? "abnormal" : ""}>{patient.k} mmol/l</td>
                  <td className={isRed(patient.calcemie, v => v <= 70.00 || v > 100.00) ? "abnormal" : ""}>{patient.calcemie} mg/l</td>
                  <td className={isRed(patient.phosphore, v => v >= 70.00) ? "abnormal" : ""}>{patient.phosphore} mg/l</td>
                  <td className={isRed(patient.pth, v => v > 150.00) ? "abnormal" : ""}>{patient.pth} pg/l</td>
                  <td className={isRed(patient.acideurique, v => v >= 80.00) ? "abnormal" : ""}>{patient.acideurique} mg/l</td>
                  <td>{patient.proteinurie}</td>
                  <td>{patient.hematurie}</td>
                  <td>{patient.leucocyturie}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" style={{ textAlign: "center", padding: "20px" }}>
                  Aucune demande en attente.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>

    </div>
  </>
    
  );
}
