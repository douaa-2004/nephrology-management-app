import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import "../../css/consultationbillan.css";
import { useNavigate } from "react-router-dom";

 
  export default function LastBilan({numcartt}) {
    const location = useLocation();
  const { numcart } = location.state || numcartt || {};
  const [bilan, setBilan] = useState(null);
  const [patients, setPatients] = useState([])




  useEffect(() => {
    if (!numcart) return;

    fetch(`http://localhost:5000/api/medcin/bilan/${numcart}`)
      .then((res) => res.json())
      .then((data) => setBilan(data))
      .catch((err) => console.error("Erreur lors du fetch du bilan:", err));
  }, [numcart]);
 
  const isRed = (value, rule) => {
    const v = parseFloat(value);
    return isNaN(v) ? false : rule(v);
  };
  if (!bilan) return <p style={{
    fontSize: "50px",
    marginTop: "200px",
    textAlign: "center",
    color: "1A76D1", 
    width: "100%",
  }} >aucun  billan trouvée </p>;

  return(


    <div className="bilan-wrapper">
      <h1 className="bilan-title">Bilan patient</h1>
      <div className="bilan-info">
        <p><strong>Nom:</strong> {bilan.nom}</p>
        <p><strong>Prénom:</strong> {bilan.prenom}</p>
        <p><strong>Numéro de carte:</strong> {bilan.numcart}</p>
        <p><strong>Date:</strong> {new Date(bilan.created_at).toLocaleDateString()}</p>
      </div>

      <table className="bilan-table">
        <thead>
          <tr>
            <th>Analyse</th>
            <th>Valeur</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>HB</td><td className={isRed(bilan.hb, v => v > 8.00) ? "abnormal" : ""}>{bilan.hb} g/dl</td></tr>
          <tr><td>GB</td><td>{bilan.gb}</td></tr>
          <tr><td>Plq</td><td>{bilan.plq}</td></tr>
          <tr><td>Urée</td><td className={isRed(bilan.uree, v => v < 2.00) ? "abnormal" : ""}>{bilan.uree} g/l</td></tr>
          <tr><td>Créat</td><td className={isRed(bilan.creat, v => v < 30.00) ? "abnormal" : ""}>{bilan.creat} mg/l</td></tr>
          <tr><td>Na⁺</td><td className={isRed(bilan.na, v => v <= 125.00 || v >= 145.00) ? "abnormal" : ""}>{bilan.na} mmol/l</td></tr>
          <tr><td>K⁺</td><td className={isRed(bilan.k, v => v > 6.00 || v < 3.50) ? "abnormal" : ""}>{bilan.k} mmol/l</td></tr>
          <tr><td>Calcémie</td><td className={isRed(bilan.calcemie, v => v <= 70.00 || v > 100.00) ? "abnormal" : ""}>{bilan.calcemie} mg/l</td></tr>
          <tr><td>Phosphorémie</td><td className={isRed(bilan.phosphore, v => v >= 70.00) ? "abnormal" : ""}>{bilan.phosphore} mg/l</td></tr>
          <tr><td>PTH</td><td className={isRed(bilan.pth, v => v > 150.00) ? "abnormal" : ""}>{bilan.pth} pg/l</td></tr>
          <tr><td>Acide urique</td><td className={isRed(bilan.acideurique, v => v >= 80.00) ? "abnormal" : ""}>{bilan.acideurique} mg/l</td></tr>
          <tr><td>Protéinurie</td><td>{bilan.proteinurie}</td></tr>
          <tr><td>Hématurie</td><td>{bilan.hematurie}</td></tr>
          <tr><td>Leucocyturie</td><td>{bilan.leucocyturie}</td></tr>
        </tbody>
      </table>
    </div>
  )
  }