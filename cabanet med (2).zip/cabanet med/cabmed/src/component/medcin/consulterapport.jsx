import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../css/consultrapport.css";

export default function ConsulterRapport() {
  const [patients, setPatients] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/medcin/consulter-rapport");
      const data = await res.json();
      if (data.success) setPatients(data.demandes || []);
    } catch (err) {
      console.error("Erreur lors du chargement des demandes :", err);
    }
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2 className="patients-title">📋 Demandes de Rapport Médical en Attente</h2>
          <div className="table-wrapper">
            <table className="patients-table">
              <thead>
                <tr>
                  <th>Numéro de Carte</th>
                  <th>Nom</th>
                  <th>Prénom</th>
                  <th>Téléphone</th>
                  <th>Email</th>
                  <th>Date de demande</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {patients.length > 0 ? (
                  patients.map((patient) => (
                    <tr key={patient.id}>
                      <td>{patient.numcart}</td>
                      <td>{patient.lastname}</td>
                      <td>{patient.firstname}</td>
                      <td>{patient.phone}</td>
                      <td>{patient.email}</td>
                      <td>{new Date(patient.created_at).toLocaleString().slice(0, 10)}</td>
                      <td>
                        <button
                          className="btn-action"
                          onClick={() => {
                            navigate("/admindash/validerrapport", { state: { numcart: patient.numcart } });
                          }}
                        >
                          Valider Rapport
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" className="no-data">
                      Aucune demande en attente.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}