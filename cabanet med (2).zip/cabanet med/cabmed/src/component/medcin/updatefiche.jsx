import React, { useState } from "react";
import "../../css/fichclinique.css"; 

export default function UpdateFicheClinique() {
  const [fiche, setFiche] = useState({
    numcart: "",
    sexe: "",
    ant_med: "",
    ant_chir: "",
    ant_gyneco: "",
    habitudes: "",
    ant_familiaux: "",
    examen_clinique: "",
  });

  const [notFound, setNotFound] = useState(false);

  const handleChange = async (e) => {
    const { name, value } = e.target;

    setFiche((prev) => ({ ...prev, [name]: value }));

    if (name === "numcart" && value.length > 2) {
      try {
        const res = await fetch(`http://localhost:5000/api/medcin/get-fiche-clinique/${value}`);
        const data = await res.json();
        if (data.success) {
          setFiche(data.fiche);
          setNotFound(false);
        } else {
          setNotFound(true);
        }
      } catch (err) {
        console.error("Erreur de récupération du numcart :", err);
      }
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`http://localhost:5000/api/medcin/update-fiche-clinique/${fiche.numcart}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(fiche),
      });

      const data = await res.json();
      if (data.success) {
        alert("Fiche mise à jour !");
      } else {
        alert("Erreur de mise à jour !");
      }
    } catch (err) {
      console.error("Erreur de mise à jour :", err);
    }
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2>Modifier la Fiche Clinique</h2>
          <form onSubmit={handleUpdate} className="fiche-form">
            <input
              type="text"
              name="numcart"
              value={fiche.numcart}
              onChange={handleChange}
              placeholder="Numéro de carte"
            />
            {notFound && <p style={{ color: "red" }}>Fiche introuvable pour ce numéro</p>}

            <select name="sexe" value={fiche.sexe} onChange={handleChange}>
              <option value="">Sélectionner le sexe</option>
              <option value="Homme">Homme</option>
              <option value="Femme">Femme</option>
            </select>

            <textarea
              name="ant_med"
              placeholder="Antécédents médicaux"
              value={fiche.ant_med}
              onChange={handleChange}
            />
            <textarea
              name="ant_chir"
              placeholder="Antécédents chirurgicaux"
              value={fiche.ant_chir}
              onChange={handleChange}
            />

            {fiche.sexe === "Femme" && (
              <textarea
                name="ant_gyneco"
                placeholder="Antécédents gynéco-obstétricaux"
                value={fiche.ant_gyneco}
                onChange={handleChange}
              />
            )}

            <textarea
              name="habitudes"
              placeholder="Habitudes de vie"
              value={fiche.habitudes}
              onChange={handleChange}
            />
            <textarea
              name="ant_familiaux"
              placeholder="Antécédents familiaux"
              value={fiche.ant_familiaux}
              onChange={handleChange}
            />
            <textarea
              name="examen_clinique"
              placeholder="Examen clinique"
              value={fiche.examen_clinique}
              onChange={handleChange}
            />

            <button type="submit">Mettre à jour</button>
          </form>
        </div>
      </div>
    </div>
  );
}