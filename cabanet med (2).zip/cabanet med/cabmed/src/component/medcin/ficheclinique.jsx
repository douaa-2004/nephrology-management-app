import React, { useState } from "react";
import "../../css/fichclinique.css"; 

export default function FicheClinique() {
  const [fiche, setFiche] = useState({
    numcart: "",
    sexe: "",
    antMed: "",
    antChir: "",
    antGyneco: "",
    habitudes: "",
    antFamiliaux: "",
    examenClinique: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFiche((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/api/medcin/add-fiche-clinique", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(fiche),
      });

      const data = await response.json();

      if (data.success) {
        alert("Fiche clinique enregistrée avec succès !");
        setFiche({
          numcart: "",
          sexe: "",
          antMed: "",
          antChir: "",
          antGyneco: "",
          habitudes: "",
          antFamiliaux: "",
          examenClinique: "",
        });
      } else {
        alert("Erreur lors de l'enregistrement");
      }
    } catch (err) {
      console.error("Erreur lors de l'envoi de la fiche :", err);
    }
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2>Fiche Clinique – Première Consultation</h2>
          <form onSubmit={handleSubmit} className="fiche-form">
            <input
              type="text"
              name="numcart"
              placeholder="Numéro de carte"
              value={fiche.numcart}
              onChange={handleChange}
              required
            />

            <select name="sexe" value={fiche.sexe} onChange={handleChange}>
              <option value="">Sélectionner le sexe</option>
              <option value="Homme">Homme</option>
              <option value="Femme">Femme</option>
            </select>

            <textarea
              name="antMed"
              placeholder="Antécédents médicaux"
              value={fiche.antMed}
              onChange={handleChange}
            />
            <textarea
              name="antChir"
              placeholder="Antécédents chirurgicaux"
              value={fiche.antChir}
              onChange={handleChange}
            />

            {fiche.sexe === "Femme" && (
              <textarea
                name="antGyneco"
                placeholder="Antécédents gynéco-obstétricaux"
                value={fiche.antGyneco}
                onChange={handleChange}
              />
            )}

            <textarea
              name="habitudes"
              placeholder="Habitudes de vie (tabac, alcool, autres...)"
              value={fiche.habitudes}
              onChange={handleChange}
            />

            <textarea
              name="antFamiliaux"
              placeholder="Antécédents familiaux"
              value={fiche.antFamiliaux}
              onChange={handleChange}
            />

            <textarea
              name="examenClinique"
              placeholder="Examen clinique (rédigé par le médecin)"
              value={fiche.examenClinique}
              onChange={handleChange}
            />

            <button type="submit">Enregistrer la fiche</button>
          </form>
        </div>
      </div>
    </div>
  );
}
