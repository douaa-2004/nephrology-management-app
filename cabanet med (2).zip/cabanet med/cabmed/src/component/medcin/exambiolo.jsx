
import { useState, useRef, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { useReactToPrint } from "react-to-print";
import "../../css/examradio.css";

const exams =[
  "PROTEINES DES 24H", "CREAT URINAIRE", "CHL URINAIRE", "A.URIQUE URINAIRE", "GLYCEMIE POST-PRANDIAL", "FT3", "HIV",
  "ECB LCR", "PARASITOLOGIE", "ECB DU PUS","CRP", "Na+ URINAIRE", "CA++ URINAIRE","AMYLASE",
  "TROPONINE(TNHS)", "TSH3", "ECBU", "HEMOCULTURE", "PRELEVEMENT VAGINAL", "test","UREE URINAIRE", "K+ URINAIRE",
  "PHOS-URINAIRE", "ALBUMINE", "FT4(FT4N)", "SEROLOGIE DE WRIGHT", "ATB", "COPRO CUTRUE", "P.ORL", "vf", "FNS", "PHENOTYPE",
  "TCK", "GLYCEMIE", "KALIEMIE(K+)","PHOSPHOREMIE","BILIRUBINE DIRECTE", "CHOLESTROL TOTAL", "LDL",
  "FERRITINE", "V DE SEDIMENTATION","TAUX DE PROTHROMBINE", "UREE SANGUIN", "CREATININE SANGUINE","CHLORE(CL-)", "ACIDE URIQUE", "ASAT(GO)", "TRIGLYCERIDE", "FER SERIQUE","COEFFICIENT DE SATURATION",
  "GROUPE RHESUS", "INR", "UREE POST_DIALYSE", "NATREMIE","CALCEMIE", "BILIRUBINE TOTALE", "ALAT(GP)","HDL", "TIBC", "PROTIDES TOTAUX"
]

export default function Exambiolo() {
  const location = useLocation();
  const { numcart } = location.state || {};
  const [patientData, setPatientData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [uploadStatus, setUploadStatus] = useState("");
  const printRef = useRef(null);

  useEffect(() => {
    if (numcart) {
      fetch(`http://localhost:5000/api/assestant/getinfopatient/${numcart}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            setPatientData(data.patient);
          }
          setLoading(false);
        })
        .catch((err) => {
          console.error(err);
          setLoading(false);
        });
    }
  }, [numcart]);

  const handleChange = (exam) => {
    setSelected((prev) =>
      prev.includes(exam) ? prev.filter((e) => e !== exam) : [...prev, exam]
    );
  };

  const handleDownloadPDF = () => {
    if (!printRef.current) return;
    html2canvas(printRef.current, { scale: 2 }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      const blob = pdf.output("blob");
      const file = new File([blob], "exam_biologique.pdf", {
        type: "application/pdf",
      });

      const formData = new FormData();
      formData.append("pdfFile", file);
      formData.append("numcart", numcart);

      fetch("http://localhost:5000/api/exam/upload", {
        method: "POST",
        body: formData,
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            setUploadStatus("Le fichier a été uploadé avec succès.");
          } else {
            setUploadStatus("Erreur lors de l'upload du fichier.");
          }
          setShowPopup(true);
        })
        .catch((err) => {
          console.error("Erreur d'envoi:", err);
        });
    });
  };

 const handlePrint = () => {
  const content = printRef.current;
  if (!content) {
    alert("Il n'y a rien à imprimer !");
    return;
  }
  
  const printWindow = window.open("", "", "width=800,height=600");
  if (!printWindow) {
    console.error("Impossible d'ouvrir la fenêtre d'impression.");
    return;
  }

  printWindow.document.open();
  printWindow.document.write(`
    <html>
      <head>
        <title>Demande d'Examens Médicaux Radiologiques</title>
        <style>
          @page { size: A4; margin: 20mm; }
          body { font-family: Arial, sans-serif; margin: 0; padding: 20px;  }
          h1, h2, h3 { color: #1A76D1; }
          ul { list-style-type: disc; margin-left: 20px; }
          .pdf-area { max-width: 700px; margin: auto; position: relative; height: 270mm; }
          .pdf-title { text-align: center; }
          .pdf-subtitle { text-align: center; margin-bottom: 20px; }
          .pdf-list li { margin-bottom: 6px; font-size: 16px; }
          .pdf-signature { margin-top: 40px; font-weight: bold; position: absolute; bottom: 20px; left: 50px; }
        </style>
      </head>
      <body>
        <div class="pdf-area">
          ${content.innerHTML}
        </div>
      </body>
    </html>
  `);
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
};

  const closePopup = () => {
    setShowPopup(false);
    setUploadStatus("");
  };
  
  return (
    <div className="exam-wrapper">
      <h2 className="form-title">Sélectionner les examens à demander</h2>
      <div className="checkbox-grid">
        {exams.map((exam, index) => (
          <div key={index} className="checkbox-perant">
            <input
              className="checkbox-input"
              type="checkbox"
              value={exam}
              onChange={() => handleChange(exam)}
              checked={selected.includes(exam)}
            />
            <label className="checkbox-item">{exam}</label>
          </div>
        ))}
      </div>

     
      {!loading && (
        <div className="pdf-area" ref={printRef}>
          <h1 className="pdf-title">Clinique Elnadjeh</h1>
          <h2 className="pdf-subtitle">Demande d’Examens Médicaux biologique</h2>
          <p><strong>Date:</strong> {new Date().toLocaleDateString()}</p>

          <div className="patient-info" style={{ marginTop: "20px" }}>
            <p><strong>Nom:</strong> {patientData?.firstname}</p>
            <p><strong>Prénom:</strong> {patientData?.lastname}</p>
            <p><strong>Téléphone:</strong> {patientData?.phone}</p>
            <p><strong>Email:</strong> {patientData?.email}</p>
          </div>

          <ul className="pdf-list">
            <h3>Bilan biologiques à faire :</h3>
            {selected.map((exam, idx) => (
              <li key={idx}>{exam}</li>
            ))}
          </ul>

          <div className="pdf-signature">Signature du Médecin</div>
        </div>
      )}

     <div className="btn-impr" style={{display:"flex" ,
      justifyContent : "center"
     }} >
       <button className="btn-generate" onClick={handleDownloadPDF}>
        📄 Générer le PDF
      </button>

   <button
  className="btn-generate"
  onClick={handlePrint}
  disabled={!printRef.current}
>
  🖨️ Imprimer
</button>

     </div>

      {showPopup && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 9999,
          }}
        >
          <div
            style={{
              backgroundColor: "white",
              padding: "30px",
              borderRadius: "12px",
              textAlign: "center",
              boxShadow: "0px 0px 15px rgba(0, 0, 0, 0.3)",
            }}
          >
            <h2>Fichier Uploadé</h2>
            <p>{uploadStatus}</p>
            <button onClick={closePopup}>Fermer</button>
          </div>
        </div>
      )}
    </div>
  );
}
