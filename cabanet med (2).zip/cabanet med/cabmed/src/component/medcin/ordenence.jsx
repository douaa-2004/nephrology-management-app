import React, { useRef, useState } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import "../../css/ordonnance.css";

export default function OrdonnanceGenerator() {
  const printRef = useRef();

  const [meds, setMeds] = useState([
    { name: "", dosage: "", type: "", instructions: "", qte: 1 },
  ]);

  const handleChange = (index, field, value) => {
    const updated = [...meds];
    updated[index][field] = value;
    setMeds(updated);
  };

  const handleAddRow = () => {
    setMeds([
      ...meds,
      { name: "", dosage: "", type: "", instructions: "", qte: 1 },
    ]);
  };

  const handleDownloadPDF = () => {
    const input = printRef.current;
    html2canvas(input, { scale: 2 }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save("ordonnance.pdf");
    });
  };

  const handlePrint = () => {
    const content = printRef.current;
    const printWindow = window.open('', '', 'width=800,height=600');
    
    if (printWindow) {
      printWindow.document.open();
  
      
      printWindow.document.write(`
        <html>
          <head>
            <title>Ordonnance Print</title>
            <style>
              @page { size: A4; margin: 0; }
              body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
              .ordonnance-wrapper { max-width: 900px; margin: auto; padding: 40px; background: #f5f5f5; color: #1A76D1; }
              .ordonnance-form h2 { color: #1A76D1; margin-bottom: 15px; }
              .input-row { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 15px; }
              .input-row input { padding: 8px; flex: 1 1 180px; border: 1px solid #ccc; border-radius: 5px; }
              button { margin-top: 15px; padding: 10px 20px; background: #1A76D1; color: white; border: none; border-radius: 6px; cursor: pointer; }
              .ordonnance-paper { background: white; padding: 30px; width: 210mm; height: 297mm; margin-top: 50px; display: flex; flex-direction: column; border: 2px solid #1A76D1; box-shadow: 0 0 15px rgba(0,0,0,0.1); font-size: 18px;   position: relative; }
              .ordonnance-header h1 { font-size: 28px; margin-bottom: 5px; }
              .ordonnance-header h2 { font-size: 22px; margin-bottom: 10px; }
              .ordonnance-body { margin-top: 20px; }
              .ordonnance-body h3 { text-align: center; font-size: 24px; margin-bottom: 15px; color: #1A76D1; font-weight: bold; }
              .ord-item { margin: 50px; border-bottom: #1A76D1 1px solid; padding-bottom: 30px; }
              .ord-line { display: flex; justify-content: space-between; font-weight: bold; font-size: 20px; }
              .ord-instruction { margin-top: 15px; font-weight: bold; color: #333; }
               .ordonnance-footer { font-size: 18px; color: #1A76D1; position: absolute;   bottom: 50px; left: 70px;  }
              .signature-line { height: 2px; background: #1A76D1; margin-top: 20px; width: 200px; }
            </style>
          </head>
          <body>
            ${content.innerHTML}
          </body>
        </html>
      `);
  
      printWindow.document.close(); 
      printWindow.print(); 
    } else {
      console.error('The print window could not be opened.');
    }
  };
  return (
    <div className="ordonnance-wrapper">
      <div className="ordonnance-form">
        <h2>Rédiger l'Ordonnance</h2>
        {meds.map((med, index) => (
          <div className="input-row" key={index}>
            <input
              placeholder="Médicament"
              value={med.name}
              onChange={(e) => handleChange(index, "name", e.target.value)}
            />
            <input
              placeholder="Dosage"
              value={med.dosage}
              onChange={(e) => handleChange(index, "dosage", e.target.value)}
            />
            <input
              placeholder="Type (comprimé, injection...)"
              value={med.type}
              onChange={(e) => handleChange(index, "type", e.target.value)}
            />
            <input
              placeholder="Instructions (ex: 1cp/jour...)"
              value={med.instructions}
              onChange={(e) => handleChange(index, "instructions", e.target.value)}
            />
            <input
              type="number"
              placeholder="Qté"
              value={med.qte}
              onChange={(e) => handleChange(index, "qte", e.target.value)}
            />
          </div>
        ))}
        <button onClick={handleAddRow}>Ajouter un médicament</button>
      </div>

      <div className="ordonnance-paper" ref={printRef}>
        <div className="ordonnance-header">
          <h1>Clinique Elnadjeh</h1>
          <h2>Dr. Zakaria Bounedjma</h2>
          <p>Date : {new Date().toLocaleDateString()}</p>
        </div>

        <div className="ordonnance-body">
          <h3>Ordonnance Médicale</h3>
          {meds.map((med, idx) => (
            <div className="ord-item" key={idx}>
              <div className="ord-line">
                <span><strong>{med.name}</strong> — {med.dosage} — {med.type}</span>
                <span className="ord-qte">Qté: {med.qte}</span>
              </div>
              <div className="ord-instruction">{med.instructions}</div>
            </div>
          ))}
        </div>

        <div className="ordonnance-footer">
          <p>Signature du médecin</p>
          <div className="signature-line" />
        </div>
      </div>
      <button onClick={handleDownloadPDF}>📄 Télécharger PDF</button>
      <button onClick={handlePrint}>🖨️ Imprimer l’ordonnance</button>
    </div>
  );
}
