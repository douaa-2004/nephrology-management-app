import "../../css/adminnav.css"
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { signinsuccess } from "../../../redux/user/userslice";
import { useState } from "react";

export default function Patientnav() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
   const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    dispatch(signinsuccess(null)); 
    navigate("/");
  };

  return (
    <>
     <button className="toggle-button" onClick={() => setIsOpen(!isOpen)}>
        ☰
      </button>

      <nav className={`sidebar ${isOpen ? "active" : ""}`}>
        <ul className="sidebar-list">
          <li>
            <Link to="/patient/rapport" onClick={() => setIsOpen(false)}>
              Rapport médical
            </Link>
          </li>
          <li>
            <Link to="" onClick={() => setIsOpen(false)}>
              Les examens demandés
            </Link>
          </li>
        </ul>
        <button className="logout-button" onClick={handleLogout}>
          Se déconnecter
        </button>
      </nav>
      </>
  );
}
