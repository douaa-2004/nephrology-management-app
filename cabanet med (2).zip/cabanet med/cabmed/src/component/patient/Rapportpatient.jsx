import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";

export default function Rapportpatient() {
  const numcart = useSelector((state) => state.user.currentUser.patient.numcart);
  const [reportLink, setReportLink] = useState(null);
  const [waiting, setWaiting] = useState(() => localStorage.getItem("waitingForReport") === "true");

  useEffect(() => {
    fetch(`http://localhost:5000/api/patient/rapport/${numcart}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setReportLink(data.link);
          setWaiting(false);
          localStorage.removeItem("waitingForReport");
        }
      })
      .catch((err) => console.error("Erreur rapport:", err));
  }, [numcart]);

  const handleClick = async () => {
    setWaiting(true);
    localStorage.setItem("waitingForReport", "true");

    try {
      await fetch(`http://localhost:5000/api/patient/demander-rapport/${numcart}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
    } catch (err) {
      console.error("Erreur demande rapport:", err);
    }
  };

  return (
    <div style={{
      width: "100%",
      margin:"100px 0",
      padding: "30px 20px",
      fontFamily: "Arial, sans-serif",
      
      display: "flex",
      justifyContent: "center",
      alignItems: "flex-start", 
    }}>
      <div style={{
        maxWidth: "600px",
        width: "100%",
        background: "#fff",
        padding: "30px",
        borderRadius: "10px",
        boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
        textAlign: "center"
      }}>
        <h2 style={{ color: "#1A76D1", marginBottom: "20px" }}>Rapport Médical</h2>
        <p style={{ fontSize: "17px", color: "#333", marginBottom: "25px" }}>
          Cette page vous permet de consulter ou demander la génération de votre rapport médical.
        </p>

        {reportLink ? (
          <div>
            <p style={{ fontSize: "18px", color: "#4CAF50", fontWeight: "bold", marginBottom: "20px" }}>
              ✅ Votre rapport est prêt !
            </p>
            <a
              href={reportLink}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: "inline-block",
                backgroundColor: "#1A76D1",
                color: "white",
                padding: "12px 24px",
                borderRadius: "6px",
                textDecoration: "none",
                fontSize: "16px"
              }}
            >
              📥 Télécharger le rapport
            </a>
          </div>
        ) : waiting ? (
          <div>
            <p style={{ fontSize: "18px", color: "#777", marginBottom: "15px" }}>
              ⏳ Rapport en cours de traitement...
            </p>
            <p style={{ fontSize: "16px", color: "#999" }}>
              Merci de patienter pendant que le médecin finalise votre rapport.
            </p>
          </div>
        ) : (
          <div>
            <p style={{ fontSize: "16px", color: "#555", marginBottom: "20px" }}>
              Cliquez ci-dessous pour demander la génération de votre rapport médical.
            </p>
            <button
              onClick={handleClick}
              style={{
                padding: "14px 28px",
                fontSize: "16px",
                backgroundColor: "#1A76D1",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer"
              }}
            >
              📤 Obtenir le rapport médical
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
