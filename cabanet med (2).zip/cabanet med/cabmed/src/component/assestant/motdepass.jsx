import { useLocation } from "react-router-dom";
import '../../css/assestant/motdepass.css'; // Make sure the path is correct

export default function Motdepasse() {
  const location = useLocation();
  const password = location?.state?.password;
  const email = location?.state.email  
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="card-container print-area">
      <div className="card">
        {password ? (
          <>
            <p>Votre email est : <strong>{email}</strong></p>
            <p>Votre mot de passe est : <strong>{password}</strong></p>
            <button onClick={handlePrint} className="print-button">Imprimer</button>
          </>
        ) : (
          <p>Mot de passe introuvable</p>
        )}
      </div>
    </div>
  );
}
