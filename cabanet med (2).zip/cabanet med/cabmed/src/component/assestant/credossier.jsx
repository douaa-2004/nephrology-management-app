import React, { useState } from "react";
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom"; 
import "../../css/assestant/creedossier.css";

export default function Dossier() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [error, setError] = React.useState(null);
  const [patient, setPatient] = useState({
    numcart: "",
    firstName: "",
    lastName: "",
    birthDate: "",
    gender: "",
    phone: "",
    email: "",
    consultationReason: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPatient((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/assestant/ajoutedossier", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(patient),
      });
      const data = await response.json();
      if (data.success === false) {
        setError(data.message);
        return;
      }
      navigate("/assestant/motdepass", { state: { password: data.patient.motdepasse, email: data.patient.email } });
      setError(null);
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2>Créer un Dossier Patient</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="numcart"
              placeholder="Numéro de la carte"
              value={patient.numcart}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="firstName"
              placeholder="Prénom"
              value={patient.firstName}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="lastName"
              placeholder="Nom"
              value={patient.lastName}
              onChange={handleChange}
              required
            />
            <input
              type="date"
              name="birthDate"
              value={patient.birthDate}
              onChange={handleChange}
              required
            />
            <select name="gender" value={patient.gender} onChange={handleChange} required>
              <option value="">Sexe</option>
              <option value="Male">Homme</option>
              <option value="Female">Femme</option>
            </select>
            <input
              type="tel"
              name="phone"
              placeholder="Téléphone"
              value={patient.phone}
              onChange={handleChange}
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={patient.email}
              onChange={handleChange}
              required
            />
            <textarea
              name="consultationReason"
              placeholder="Motif de consultation"
              value={patient.consultationReason}
              onChange={handleChange}
              required
            ></textarea>
            <button type="submit">
              <i className="fas fa-save"></i> Enregistrer
            </button>
            {error && (
              <div className="popbillan">
                <div className="popmessage">
                  <p className="poptalk">Erreur: {error}</p>
                  <button onClick={() => setError(null)}>
                    <i className="fas fa-check"></i> OK
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}