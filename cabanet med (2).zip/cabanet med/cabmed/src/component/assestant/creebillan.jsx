import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../css/assestant/updatebillan.css";

export default function Billan() {
  const navigate = useNavigate();
  const initialBilanState = {
    numcart: "",
    nom: "",
    prenom: "",
    hb: "",
    gb: "",
    plq: "",
    uree: "",
    creat: "",
    na: "",
    k: "",
    calcemie: "",
    phosphore: "",
    pth: "",
    acideUrique: "",
    proteinurie: "",
    hematurie: "",
    leucocyturie: "",
  };

  const [bilan, setBilan] = useState(initialBilanState);
  const [data, setData] = React.useState({
    message: "",
    success: false,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBilan((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/assestant/ajouterbillan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(bilan),
      });

      const responseData = await response.json();

      if (responseData.success === false) {
        setData({ message: responseData.message, success: false });
        return;
      }
      setData({ message: responseData.message, success: true });
    } catch (error) {
      setData({ message: error.message, success: false });
    }
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2>Créer un Bilan Patient</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="numcart"
              placeholder="Numéro de la carte"
              value={bilan.numcart}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="nom"
              placeholder="Nom"
              value={bilan.nom}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="prenom"
              placeholder="Prénom"
              value={bilan.prenom}
              onChange={handleChange}
              required
            />
            <input
              type="number"
              step="0.01"
              name="hb"
              placeholder="Hb (g/dl)"
              value={bilan.hb}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="gb"
              placeholder="GB"
              value={bilan.gb}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="plq"
              placeholder="Plq"
              value={bilan.plq}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="uree"
              placeholder="Urée (g/l)"
              value={bilan.uree}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="creat"
              placeholder="Créatinine (mg/l)"
              value={bilan.creat}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="na"
              placeholder="Na+ (mmol/l)"
              value={bilan.na}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="k"
              placeholder="K+ (mmol/l)"
              value={bilan.k}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="calcemie"
              placeholder="Calcémie (mg/l)"
              value={bilan.calcemie}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="phosphore"
              placeholder="Phosphorémie (mg/l)"
              value={bilan.phosphore}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="pth"
              placeholder="PTH (pg/l)"
              value={bilan.pth}
              onChange={handleChange}
            />
            <input
              type="number"
              step="0.01"
              name="acideUrique"
              placeholder="Acide urique (mg/l)"
              value={bilan.acideUrique}
              onChange={handleChange}
            />
            <input
              type="text"
              name="proteinurie"
              placeholder="Protéinurie"
              value={bilan.proteinurie}
              onChange={handleChange}
            />
            <input
              type="text"
              name="hematurie"
              placeholder="Hématurie"
              value={bilan.hematurie}
              onChange={handleChange}
            />
            <input
              type="text"
              name="leucocyturie"
              placeholder="Leucocyturie"
              value={bilan.leucocyturie}
              onChange={handleChange}
            />
            <button type="submit">
              <i className="fas fa-save"></i> Enregistrer le Bilan
            </button>
            {data.message && (
              <div className="popbillan">
                <div className="popmessage">
                  <p className="poptalk">
                    {data.success
                      ? "Le bilan a été enregistré avec succès. Merci !"
                      : `Erreur: ${data.message}`}
                  </p>
                  <button
                    onClick={() => {
                      setBilan(initialBilanState);
                      setData({ message: "", success: false });
                    }}
                  >
                    <i className="fas fa-check"></i> OK
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}