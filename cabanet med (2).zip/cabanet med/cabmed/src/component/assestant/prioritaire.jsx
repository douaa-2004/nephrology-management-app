import React, { useEffect, useState } from "react";
import "../../css/assestant/priority.css"; 

export default function PatientsList() {
  const [patients, setPatients] = useState([]);

  const fetchPatients = async () => {
    const res = await fetch("http://localhost:5000/api/assestant/recent-patients");
    const data = await res.json();
    if (data.success) setPatients(data.patients || []);
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const handlePrioritaire = async (numcart) => {
    await fetch(`http://localhost:5000/api/assestant/set-prioritaire/${numcart}`, { method: "PUT" });
    fetchPatients();
  };

  const handleDeprioritaire = async (numcart) => {
    await fetch(`http://localhost:5000/api/assestant/remove-prioritaire/${numcart}`, { method: "PUT" });
    fetchPatients();
  };

  return (
    <div className="fiche-container-wrapper">
      <div className="fiche-content">
        <div className="fiche-container">
          <h2>Patients arrivés dans les dernières 24h</h2>
          <div className="table-wrapper">
            <table className="patients-table">
              <thead>
                <tr>
                  <th>Nom</th>
                  <th>Prénom</th>
                  <th>Heure d'arrivée</th>
                  <th>Raison</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {patients.map((patient) => (
                  <tr key={patient.numcart}>
                    <td>{patient.firstname}</td>
                    <td>{patient.lastname}</td>
                    <td>{new Date(patient.created_at).toLocaleTimeString()}</td>
                    <td>{patient.consultationreason}</td>
                    <td>
                      <button
                        className={`btn-action ${patient.is_prioritaire ? "deprioritaire" : "prioritaire"}`}
                        onClick={() =>
                          patient.is_prioritaire
                            ? handleDeprioritaire(patient.numcart)
                            : handlePrioritaire(patient.numcart)
                        }
                      >
                        {patient.is_prioritaire ? (
                          <>
                            <i className="fas fa-minus-circle"></i> Déprioriser
                          </>
                        ) : (
                          <>
                            <i className="fas fa-exclamation-circle"></i> Prioritaire
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}