import './App.css';
import HOME from './component/home';
import Login from './pageroute/login';
import Admindash from './pageroute/admindash';
import Assestantdash from './pageroute/assestantdash';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useSelector } from 'react-redux';
import ProtectedRoute from '../protectedRoute';
import Patientdash from './pageroute/patientdash';
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HOME />} />
        <Route path="/login" element={<Login />} />

        <Route element={<ProtectedRoute allowedRoles={['medcin']} />}>
          <Route path="/admindash/*" element={<Admindash />} />
        </Route>
        <Route element={<ProtectedRoute allowedRoles={['assestant']} />}>
          <Route path="/assestant/*" element={<Assestantdash />} />
        </Route>
        <Route element={<ProtectedRoute allowedRoles={['patient']} />}>
          <Route path="/patient/*" element={<Patientdash/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
