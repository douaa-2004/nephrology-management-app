import { combineReducers, configureStore } from "@reduxjs/toolkit";
import userReducer from "./user/userslice" ;
import { persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";

// Combine all reducers (only one for now)
const rootReducer = combineReducers({ user: userReducer });

// Persist config
const persistConfig = {
  key: "root",
  storage,
  version: 1,
};

// Create a persisted reducer
const persistedReducer = persistReducer(persistConfig, rootReducer);

// Create the store
export const store = configureStore({
  reducer: persistedReducer,  // ✅ Directly assign persistedReducer
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ serializableCheck: false }), // ✅ Avoid Redux Persist errors
});

// Create the persistor
export const persistor = persistStore(store);

