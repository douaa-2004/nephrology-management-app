import {createSlice} from "@reduxjs/toolkit"


const initialState = {
    currentUser : null , 
    error : null , 
    loading : false ,

};
const userSlice = createSlice({
    name : "user" , 
    initialState ,
    reducers:{

        signinsuccess : (state , action ) => {
            state.currentUser = action.payload
            state.loading = false
            state.error = null
        } , 
        signInfailure : (state , action )=>{
            state.error = action.payload
            state.loading = false
        } , 
        upadatestart : (state)=>{
            state.loading = true
        } , 
        updatesucces : (state , action )=>{
            state.currentUser = action.payload 
            state.loading = false
            state.error = null; 
        },
        updatefailure : (state , action )=>{
            state.error = action.payload
            state.loading = false
        } 
    }
})
export const { signinsuccess ,signInfailure , upadatestart ,updatesucces , updatefailure} = userSlice.actions
export default userSlice.reducer